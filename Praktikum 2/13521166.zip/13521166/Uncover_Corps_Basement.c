/*
Nama    : Mohammad Rifqi Farhansyah
NIM     : 13521166
Praktikum Arsikom No 3
*/

#include <stdlib.h>
#include <stdio.h>

void Uncover_Corps_Basement(char* input) {
    if (strings_not_equal(input, "Looks like I have to tell you something, you've done this task 168 times.")){
        illegal_move();
    }
}